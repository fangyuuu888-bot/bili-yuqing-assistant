// Background Service Worker
// 处理扩展图标点击、消息中转、数据存储

// 监听扩展图标点击 - 打开仪表盘
chrome.action.onClicked.addListener(function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});

// 监听来自 content script 的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type === 'SAVE_COMMENTS') {
    // 存储评论数据
    chrome.storage.local.set({
      ['comments_' + request.videoId]: {
        data: request.data,
        platform: request.platform,
        videoId: request.videoId,
        videoTitle: request.videoTitle,
        videoAuthor: request.videoAuthor,
        timestamp: Date.now()
      }
    }, function() {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.type === 'GET_COMMENTS') {
    chrome.storage.local.get('comments_' + request.videoId, function(result) {
      sendResponse(result['comments_' + request.videoId] || null);
    });
    return true;
  }

  if (request.type === 'GET_LATEST_COMMENTS') {
    chrome.storage.local.get(null, function(all) {
      let latest = null;
      let latestKey = null;
      Object.keys(all).forEach(function(key) {
        if (key.startsWith('comments_')) {
          if (!latest || all[key].timestamp > latest.timestamp) {
            latest = all[key];
            latestKey = key;
          }
        }
      });
      sendResponse(latest);
    });
    return true;
  }

  if (request.type === 'SAVE_PROFILE') {
    chrome.storage.local.set({
      ['profile_' + request.username]: {
        data: request.data,
        platform: request.platform,
        username: request.username,
        timestamp: Date.now()
      }
    }, function() {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.type === 'GET_LATEST_PROFILE') {
    chrome.storage.local.get(null, function(all) {
      let latest = null;
      Object.keys(all).forEach(function(key) {
        if (key.startsWith('profile_')) {
          if (!latest || all[key].timestamp > latest.timestamp) {
            latest = all[key];
          }
        }
      });
      sendResponse(latest);
    });
    return true;
  }
});
