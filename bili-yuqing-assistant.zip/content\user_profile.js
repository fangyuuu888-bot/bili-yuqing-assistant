// B站用户主页画像采集
(function() {
  'use strict';

  function parseCount(str) {
    if (!str) return 0;
    str = str.trim().replace(/[^0-9.万万亿]/g, '');
    if (str.indexOf('亿') >= 0) return Math.round(parseFloat(str) * 100000000);
    if (str.indexOf('万') >= 0) return Math.round(parseFloat(str) * 10000);
    return parseInt(str) || 0;
  }

  function extractUserInfo() {
    var info = { nickname: '', uid: '', bio: '', avatar: '', followers: 0, following: 0, totalLikes: 0 };

    var nameEl = document.querySelector('.name, .h-name, .uname, [class*="name"]');
    if (nameEl) info.nickname = nameEl.textContent.trim();

    var statEls = document.querySelectorAll('.n-data, .n-statistics .n-data, [class*="fan"], [class*="follow"], [class*="like"]');
    statEls.forEach(function(el) {
      var text = el.textContent.trim();
      var num = parseCount(el.querySelector('.n-data-v, [class*="num"], [class*="value"]') ?
        el.querySelector('.n-data-v, [class*="num"], [class*="value"]').textContent : text);
      if (text.indexOf('粉丝') >= 0 || text.indexOf('fan') >= 0) info.followers = num;
      else if (text.indexOf('关注') >= 0 || text.indexOf('follow') >= 0) info.following = num;
      else if (text.indexOf('获赞') >= 0 || text.indexOf('点赞') >= 0 || text.indexOf('like') >= 0) info.totalLikes = num;
    });

    var bioEl = document.querySelector('.bio, .sign, [class*="bio"], [class*="signature"]');
    if (bioEl) info.bio = bioEl.textContent.trim();

    var avatarEl = document.querySelector('.avatar img, .face img, [class*="avatar"] img');
    if (avatarEl) info.avatar = avatarEl.src || '';

    info.uid = (location.pathname.split('/').pop() || '').replace(/\?.*$/, '');
    return info;
  }

  function extractVideos() {
    var videos = [];
    var items = document.querySelectorAll('.small-item, .video-card, [class*="video-list"] > div, [class*="list-item"]');
    var seen = {};

    for (var i = 0; i < items.length; i++) {
      var el = items[i];
      var titleEl = el.querySelector('[class*="title"], [title]');
      var title = titleEl ? (titleEl.getAttribute('title') || titleEl.textContent.trim()) : el.textContent.trim().substring(0, 50);
      if (!title || title.length < 2 || seen[title]) continue;
      seen[title] = 1;

      var playEl = el.querySelector('[class*="play"], [class*="view"]');
      var likes = playEl ? parseCount(playEl.textContent) : 0;

      var linkEl = el.querySelector('a[href]');
      var link = linkEl ? linkEl.href : '';

      var imgEl = el.querySelector('img');
      var cover = imgEl ? imgEl.src : '';

      videos.push({ title: title, likes: likes, link: link, cover: cover });
    }

    if (videos.length === 0) {
      var allLinks = document.querySelectorAll('a[href*="/video/BV"]');
      var seen2 = {};
      for (var j = 0; j < allLinks.length; j++) {
        var a = allLinks[j];
        if (seen2[a.href]) continue;
        seen2[a.href] = 1;
        var t = a.textContent.trim();
        if (t.length > 2) videos.push({ title: t.substring(0, 50), likes: 0, link: a.href, cover: '' });
      }
    }
    return videos;
  }

  async function scrollAndCollectVideos() {
    var allVideos = [];
    var seenTitles = {};
    var prevCount = 0;
    var stableCount = 0;

    for (var i = 0; i < 20; i++) {
      var batch = extractVideos();
      batch.forEach(function(v) {
        if (!seenTitles[v.title]) { seenTitles[v.title] = 1; allVideos.push(v); }
      });
      window.scrollBy(0, 600);
      await new Promise(function(r) { setTimeout(r, 800); });
      if (allVideos.length === prevCount) { stableCount++; if (stableCount >= 3) break; }
      else { stableCount = 0; prevCount = allVideos.length; }
    }

    var finalBatch = extractVideos();
    finalBatch.forEach(function(v) {
      if (!seenTitles[v.title]) { seenTitles[v.title] = 1; allVideos.push(v); }
    });
    return allVideos;
  }

  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.type !== 'COLLECT_PROFILE') return;

    (async function() {
      try {
        var userInfo = extractUserInfo();
        var videos = await scrollAndCollectVideos();

        if (videos.length === 0 && !userInfo.nickname) {
          sendResponse({ success: false, error: '未采集到用户信息，请确保在B站用户主页使用' });
          return;
        }

        var totalLikes = videos.reduce(function(s, v) { return s + (v.likes || 0); }, 0);
        sendResponse({
          success: true,
          profile: {
            nickname: userInfo.nickname || document.title.replace(/[-_|].*$/, '').trim(),
            uid: userInfo.uid, bio: userInfo.bio, avatar: userInfo.avatar,
            platform: 'bilibili', followers: userInfo.followers,
            following: userInfo.following, accountLikes: userInfo.totalLikes,
            videoCount: videos.length, videos: videos,
            totalVideoLikes: totalLikes,
            avgVideoLikes: videos.length > 0 ? Math.round(totalLikes / videos.length) : 0,
            url: location.href, timestamp: Date.now()
          }
        });
      } catch (e) {
        sendResponse({ success: false, error: '内部错误: ' + e.message });
      }
    })();
    return true;
  });

  console.log('[B站舆情助手] 用户画像采集模块已加载');
})();
